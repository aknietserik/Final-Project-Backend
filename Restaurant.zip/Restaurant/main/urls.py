from django.urls import path
from main import views


urlpatterns = [
    path('', views.HomePage, name='home-page'),
    path('register', views.RegisterAccount, name='register-account'),
    path('login', views.LoginAccount, name='login-account'),
    path('logout', views.LogoutAccount, name='logout-account'),
    path('checkout/', views.CheckoutView.as_view(), name='checkout'),
    path('add/<str:slug>', views.add, name='add')
]