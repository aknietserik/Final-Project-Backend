from django.contrib import admin
from main.models import OrderItem, Item, Order

admin.site.register(OrderItem)
admin.site.register(Item)
admin.site.register(Order)