import re
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.core.exceptions import ValidationError

class CreateUserForm(UserCreationForm):
    email = forms.EmailField(required=False)
    # password = forms.PasswordField
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def clean_password1(self, *args, **kwargs):
        password = self.cleaned_data.get('password1')
        if len(password) < 8:
            raise ValidationError('Password must contain at least 8 symbols')
        pattern = r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).+$'
        if not re.match(pattern, password):
            raise ValidationError('Password must contain at least 1 uppercase, 1 lowercase and one number')
        return password

class CheckoutForm(forms.Form):
    shipping_address = forms.CharField(required=False)
    comments = forms.CharField(required=False)
    phone_number = forms.CharField(required=False)


class CouponForm(forms.Form):
    code = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'placeholder': 'Promo code',
        'aria-label': 'Recipient\'s username',
        'aria-describedby': 'basic-addon2'
    }))
